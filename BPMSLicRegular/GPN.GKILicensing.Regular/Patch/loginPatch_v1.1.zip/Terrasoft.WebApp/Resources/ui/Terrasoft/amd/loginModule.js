﻿define(["ext-base", "terrasoft", "login-view-utils"], function(Ext, Terrasoft, loginUtils) {
	const _viewModuleAddress = "/Nui/ViewModule.aspx";
	const _licenseManagerUrl = "/ClientApp/#/LicenseManager?mode=login";
	const _workspaceExplorerUrl = "/dev";
	const _returnUrlCode = "?ReturnUrl=";
	const _module = {};
	var _licenseFailure = false;

	const init = function() {
	};

	const createImportantLinks = function(items) {
		return Ext.create("Terrasoft.HtmlControl", {
			tpl: [
				/*jshint quotmark: false */
				//jscs:disable
				"<ul id=\"{id}\">",
				"<tpl for=\"items\">",
				"<li class=\"login-links-list\">",
				"<a target=\"_blank\" class=\"login-important-link\" href=\"{href}\">",
				/*jshint quotmark: true */
				//jscs:enable
				"{caption}",
				"</a>",
				"</li>",
				"</tpl>",
				"</ul>"
			],
			id: "importantLinks",
			tplData: {
				items: items
			},
			selectors: {
				wrapEl: "#importantLinks"
			}
		});
	};

	const renderInfoView = function() {
		if (window.changePasswordMode === true) {
			return null;
		}
		const loginEmptyRowClass = "login-empty-row";
		const loginInfoLabelHeaderClass = "login-info-label-header";
		const loginSubcellSupportInfoLabelClass = "login-subcell-support-info-label";
		const loginSubcellSupportInfoTelClass = "login-subcell-support-tel-label";
		const loginSubcellSupportClass = "login-subcell-support";
		let contSupportData = null;
		let contImportantBaseLinks = null;
		if (window.supportInfo.length > 0) {
			const contInfoTable = loginUtils.createTableContainer("supportInfoTable");
			let index = 0;
			Terrasoft.each(window.supportInfo, function(elem) {
				const rowInfo = loginUtils.createRowContainer("infoRow_" + index);
				contInfoTable.items.add(rowInfo);
				let label = loginUtils.createLabel(elem.name);
				label.classes.labelClass.push(loginSubcellSupportInfoLabelClass);
				let supportInfoCell = loginUtils.createCellContainer("supportNameCell_" + index);
				supportInfoCell.classes.wrapClassName.push(loginSubcellSupportClass);
				supportInfoCell.items.add(label);
				rowInfo.items.add(supportInfoCell);

				label = loginUtils.createLabel(elem.tel);
				label.classes.labelClass.push(loginSubcellSupportInfoTelClass);
				supportInfoCell = loginUtils.createCellContainer("supportTelCell_" + index);
				supportInfoCell.classes.wrapClassName.push(loginSubcellSupportClass);
				supportInfoCell.items.add(label);
				rowInfo.items.add(supportInfoCell);
				index++;
			}, this);
			const labelSupport = Ext.create("Terrasoft.Label", {
				caption: window.supportInfoCaption,
				classes: {
					labelClass: [loginInfoLabelHeaderClass]
				}
			});
			contSupportData = loginUtils.createTableContainer("supportTable");
			let supportRow = loginUtils.createRowContainer("supportLogoRow");
			contSupportData.items.add(supportRow);
			let supportCell = loginUtils.createCellContainer("supportLogoCell");
			supportRow.items.add(supportCell);
			supportCell.items.add(labelSupport);
			supportRow = loginUtils.createRowContainer("supportDataRow");
			contSupportData.items.add(supportRow);
			supportCell = loginUtils.createCellContainer("supportNameCell");
			supportRow.items.add(supportCell);
			supportCell.items.add(contInfoTable);
		}
		if (window.importantLinks.length > 0) {
			contImportantBaseLinks = loginUtils.createTableContainer("linksBaseTable");
			let linksRow = loginUtils.createRowContainer("linksLogoRow");
			contImportantBaseLinks.items.add(linksRow);
			let linksCell = loginUtils.createCellContainer("linksLogoCell");
			linksRow.items.add(linksCell);
			const labelLinks = Ext.create("Terrasoft.Label", {
				caption: window.importantLinksCaption,
				classes: {
					labelClass: [loginInfoLabelHeaderClass]
				}
			});
			linksCell.items.add(labelLinks);
			linksRow = loginUtils.createRowContainer("linksDataRow");
			contImportantBaseLinks.items.add(linksRow);
			const itemsConfig = [];
			Terrasoft.each(window.importantLinks, function(elem) {
				itemsConfig.push({
					caption: elem.name,
					href: elem.link
				});
			}, this);
			const links = createImportantLinks(itemsConfig);
			linksCell = loginUtils.createCellContainer("supportLogoCell");
			linksCell.items.add(links);
			linksRow.items.add(linksCell);
		}
		if (contSupportData != null || contImportantBaseLinks != null) {
			const contExtendInfo = loginUtils.createCellContainer("extendInfoContainer");
			if (contSupportData != null) {
				const suppRowInfo = loginUtils.createRowContainer("supportRowInfo");
				suppRowInfo.items.add(contSupportData);
				contExtendInfo.items.add(suppRowInfo);
				const suppRowInfoEmpty = loginUtils.createRowContainer("supportRowInfoEmpty");
				suppRowInfoEmpty.classes.wrapClassName.push(loginEmptyRowClass);
				contExtendInfo.items.add(suppRowInfoEmpty);
			}
			if (contImportantBaseLinks != null) {
				contExtendInfo.items.add(contImportantBaseLinks);
			}
			return contExtendInfo;
		}
		return null;
	};

	const getWidgetView = function() {
		const loginPageWidgetInfo = window.loginPageWidgetInfo;
		if (!loginPageWidgetInfo || !loginPageWidgetInfo.visible ||
			!loginPageWidgetInfo.src) {
			return null;
		}
		const widgetIframe = Ext.create("Terrasoft.ExternalWidget", {
			"iframeSrc": window.loginPageWidgetInfo.src,
			"classes": {
				"wrapClassName": ["login-widget-container"]
			}
		});
		const widgetLoginCell = Ext.create("Terrasoft.Container", {
			id: "widgetLoginCell",
			classes: {
				wrapClassName: ["widget-wrap-class"]
			}
		});
		widgetLoginCell.items.add(widgetIframe);
		return widgetLoginCell;
	};

	const getBorderContainer = function(name, wrapClassName) {
		const cellLine = loginUtils.createCellContainer(name);
		cellLine.classes.wrapClassName.push(wrapClassName);
		return cellLine;
	};

	const renderView = function(renderTo) {
		// Class names for elements
		const headClass = "login-label-logo";
		const smallCaptionClass = "login-label-smallCaption";
		const loginPasswordEditClass = "login-textedit-login-password";
		const loginBtnClass = "login-button-login";
		const blueColorClass = "login-label-blue";
		const smallMarginClass = "login-label-smallMargin";
		const loginHelpClass = "login-label-help";
		const userManagementClass = "user-management-container";
		const versionClass = "login-label-version";
		const loginRememberClass = "login-label-remember";
		const checkboxClass = "login-checkbox-remember";
		const helperClass = "login-label-helper";
		const containerRememberClass = "login-container-remember";
		const containerFooterClass = "login-container-footer";
		const containerRememberClassInside = "login-container-remember-inside";
		const loginBorderLeftClass = "login-border-left";
		const loginBorderRightClass = "login-border-right";
		const loginEmptyCellClass = "login-empty-cell";
		const loginInsideContainerClass = "login-inside-container";
		const loginOutsideContainerClass = "login-outside-container";
		let logoImageUrl = Terrasoft.appFramework === "NETFRAMEWORK"
			? window.loginImageUrl
			: "/Login/logo.svg";
		logoImageUrl = Ext.String.format("{0}{1}",
			Terrasoft.workspaceBaseUrl, logoImageUrl);
		// elements

		const logo = Ext.create("Terrasoft.ImageEdit", {
			readonly: true,
			classes: {
				wrapClass: [headClass]
			},
			imageSrc: logoImageUrl
		});
		const loginCaption = Ext.create("Terrasoft.Label", {
			caption: Terrasoft.Resources.LoginPage.LoginEditCaption,
			classes: {
				labelClass: [smallCaptionClass]
			}
		});
		const passwordCaption = Ext.create("Terrasoft.Label", {
			caption: Terrasoft.Resources.LoginPage.PasswordEditCaption,
			classes: {
				labelClass: [smallCaptionClass, smallMarginClass]
			}
		});
		const newPasswordCaption = Ext.create("Terrasoft.Label", {
			caption: Terrasoft.Resources.LoginPage.NewPasswordEditCaption,
			classes: {
				labelClass: [smallCaptionClass, smallMarginClass]
			}
		});
		const confirmPasswordCaption = Ext.create("Terrasoft.Label", {
			caption: Terrasoft.Resources.LoginPage.ConfirmPasswordEditCaption,
			classes: {
				labelClass: [smallCaptionClass, smallMarginClass]
			}
		});
		const workspaceCaption = Ext.create("Terrasoft.Label", {
			caption: Terrasoft.Resources.LoginPage.WorkspaceEditCaption,
			classes: {
				labelClass: [smallCaptionClass, smallMarginClass]
			}
		});
		const ntlmLoginHelp = Ext.create("Terrasoft.Label", {
			caption: Terrasoft.Resources.LoginPage.NtlmLogin,
			classes: {
				labelClass: [smallCaptionClass, blueColorClass, loginHelpClass]
			},
			click: {
				bindTo: "onNtlmLoginClick"
			},
			tips: [{
				tip: {
					content: Terrasoft.Resources.LoginPage.NtlmLoginLabelHint,
					displayMode: "narrow",
					restrictAlignType: Terrasoft.AlignType.BOTTOM,
					showDelay: 2000
				}
			}]
		});
		const userManagement = Ext.create("Terrasoft.Container", {
			id: "userManagementContainer",
			selectors: {
				wrapEl: "#userManagementContainer"
			},
			classes: {
				wrapClassName: [userManagementClass]
			},
			items: [ntlmLoginHelp]
		});
		const loginEdit = Ext.create("Terrasoft.TextEdit", {
			id: "loginEdit",
			classes: {
				wrapClass: [loginPasswordEditClass]
			},
			keyup: {
				bindTo: "onKeyUp"
			},
			value: {
				bindTo: "Login"
			},
			markerValue: "loginEdit"
		});
		const passwordEdit = Ext.create("Terrasoft.TextEdit", {
			id: "passwordEdit",
			protect: true,
			classes: {
				wrapClass: [loginPasswordEditClass]
			},
			keyup: {
				bindTo: "onKeyUp"
			},
			value: {
				bindTo: "Password"
			},
			markerValue: "passwordEdit"
		});
		const newPasswordEdit = Ext.create("Terrasoft.TextEdit", {
			protect: true,
			classes: {
				wrapClass: [loginPasswordEditClass]
			},
			keyup: {
				bindTo: "onKeyUp"
			},
			value: {
				bindTo: "NewPassword"
			},
			markerValue: "newPasswordEdit"
		});
		const confirmPasswordEdit = Ext.create("Terrasoft.TextEdit", {
			protect: true,
			classes: {
				wrapClass: [loginPasswordEditClass]
			},
			keyup: {
				bindTo: "onKeyUp"
			},
			value: {
				bindTo: "ConfirmPassword"
			},
			markerValue: "confirmPasswordEdit"
		});

		const workspaceEdit = Ext.create("Terrasoft.ComboBoxEdit", {
			classes: {
				wrapClass: [loginPasswordEditClass]
			},
			keyup: {
				bindTo: "onKeyUp"
			},
			list: {
				bindTo: "workspaceList"
			},
			value: {
				bindTo: "Workspace"
			},
			markerValue: "workspaceEdit",
			prepareList: {
				bindTo: "getWorkspaceList"
			}
		});
		const btnLogin = Ext.create("Terrasoft.Button", {
			caption: Terrasoft.Resources.LoginPage.LoginButtonCaption,
			pressed: true,
			style: Terrasoft.controls.ButtonEnums.style.GREEN,
			classes: {
				textClass: [loginBtnClass]
			},
			click: {
				bindTo: "onLoginButtonClick"
			},
			markerValue: "btnLogin",
			tips: [{
				tip: {
					content: Terrasoft.Resources.LoginPage.LoginButtonHint,
					displayMode: "narrow",
					restrictAlignType: Terrasoft.AlignType.BOTTOM,
					showDelay: 2000
				}
			}],
			loading: {
				bindTo: "Loading"
			}
		});
		const btnChangePasswordLogin = Ext.create("Terrasoft.Button", {
			caption: Terrasoft.Resources.LoginPage.LoginButtonCaption,
			pressed: true,
			style: Terrasoft.controls.ButtonEnums.style.GREEN,
			classes: {
				textClass: [loginBtnClass]
			},
			click: {
				bindTo: "onChangePasswordLoginButtonClick"
			},
			markerValue: "btnChangePasswordLogin",
		});
		const checkBox = Ext.create("Terrasoft.CheckBoxEdit", {
			id: "rememberMeCheckbox",
			classes: {
				wrapClass: [checkboxClass]
			}
		});
		const checkBoxLabel = Ext.create("Terrasoft.Label", {
			caption: Terrasoft.Resources.LoginPage.RememberMeCaption,
			inputId: "rememberMeCheckbox-el",
			classes: {
				labelClass: [loginRememberClass, smallCaptionClass]
			}
		});
		const version = Ext.create("Terrasoft.Label", {
			caption: {
				bindTo: "productVersion"
			},
			classes: {
				labelClass: [smallCaptionClass, versionClass]
			}
		});
		const help = Ext.create("Terrasoft.Label", {
			caption: Terrasoft.Resources.LoginPage.Help,
			classes: {
				labelClass: [smallCaptionClass, blueColorClass, helperClass]
			},
			inputId: checkBox
		});
		const contRememberInside = Ext.create("Terrasoft.Container", {
			id: "loginRememberInsideContainer",
			selectors: {
				wrapEl: "#loginRememberInsideContainer"
			},
			classes: {
				wrapClassName: [containerRememberClassInside]
			},
			items: [checkBox, checkBoxLabel]
		});
		const contRemember = Ext.create("Terrasoft.Container", {
			id: "loginRememberContainer",
			selectors: {
				wrapEl: "#loginRememberContainer"
			},
			classes: {
				wrapClassName: [containerRememberClass]
			},
			items: [btnLogin, btnChangePasswordLogin, contRememberInside]
		});
		const contFooter = Ext.create("Terrasoft.Container", {
			id: "loginFooterContainer",
			selectors: {
				wrapEl: "#loginFooterContainer"
			},
			classes: {
				wrapClassName: [containerFooterClass]
			},
			items: [version, help]
		});
		const contLogin = _module.view = Ext.create("Terrasoft.Container", {
			id: "loginContainer",
			selectors: {
				wrapEl: "#loginContainer"
			},
			items: [loginCaption, loginEdit, passwordCaption, passwordEdit,
				newPasswordCaption, newPasswordEdit, confirmPasswordCaption, confirmPasswordEdit,
				workspaceCaption, workspaceEdit, contRemember, userManagement, contFooter
			]
		});
		const contCellLogo = loginUtils.createCellContainer("cellLogoContainer");
		contCellLogo.items.add(logo);
		const infoContainer = renderInfoView();
		const contRowLogo = loginUtils.createRowContainer("rowLogoContainer");
		if (infoContainer) {
			const paddingContainer = loginUtils.createCellContainer("rowPaddingContainer");
			contRowLogo.items.add(paddingContainer);
			contRowLogo.items.add(getBorderContainer("cellLineRightLogo", loginEmptyCellClass));
			contRowLogo.items.add(getBorderContainer("cellLineLeftLogo", loginEmptyCellClass));
		}
		contRowLogo.items.add(contCellLogo);
		const contCellLogin = loginUtils.createCellContainer("cellLoginContainer");
		contCellLogin.items.add(contLogin);
		const contRowMain = loginUtils.createRowContainer("rowMainContainer");
		if (infoContainer) {
			contRowMain.items.add(infoContainer);
			contRowMain.items.add(getBorderContainer("cellLineRight-info", loginBorderRightClass));
			contRowMain.items.add(getBorderContainer("cellLineLeft-info", loginBorderLeftClass));
		}
		contRowMain.items.add(contCellLogin);
		const widgetInfo = getWidgetView();
		if (widgetInfo) {
			contRowMain.items.add(widgetInfo);
		}
		const contTable = loginUtils.createTableContainer("tableContainer");
		contTable.items.add(contRowLogo);
		contTable.items.add(contRowMain);
		const contInside = _module.view = Ext.create("Terrasoft.Container", {
			id: "insideContainer",
			selectors: {
				wrapEl: "#insideContainer"
			},
			classes: {
				wrapClassName: [loginInsideContainerClass]
			},
			items: [contTable]
		});
		const view = _module.view = Ext.create("Terrasoft.Container", {
			id: "viewContainer",
			selectors: {
				wrapEl: "#viewContainer"
			},
			classes: {
				wrapClassName: [loginOutsideContainerClass]
			},
			items: [contInside],
			renderTo: renderTo
		});
		help.setVisible(false);
		userManagement.setVisible(true);
		const isNtlmLoginVisible = window.isNtlmLoginVisible;
		ntlmLoginHelp.setVisible(isNtlmLoginVisible);
		contRememberInside.setVisible(false);
		view.hideWorkspaceEdit = function() {
			workspaceEdit.setVisible(false);
			workspaceCaption.setVisible(false);
		};
		view.showLoginMode = function() {
			newPasswordCaption.setVisible(false);
			newPasswordEdit.setVisible(false);
			confirmPasswordCaption.setVisible(false);
			confirmPasswordEdit.setVisible(false);
			btnChangePasswordLogin.setVisible(false);
			btnLogin.setVisible(true);
		};
		view.showChangePasswordMode = function() {
			newPasswordCaption.setVisible(true);
			newPasswordEdit.setVisible(true);
			confirmPasswordCaption.setVisible(true);
			confirmPasswordEdit.setVisible(true);
			btnChangePasswordLogin.setVisible(true);
			btnLogin.setVisible(false);
		};
	};

	const prepareModel = function() {
		let version = window.productVersion;
		if (Terrasoft.frameworkDescription) {
			version += " (" + Terrasoft.frameworkDescription + ")";
		}
		_module.model = Ext.create("Terrasoft.BaseViewModel", {
			values: {
				productVersion: Terrasoft.Resources.LoginPage.Version + " " + version,
				workspaceList: Ext.create("Terrasoft.Collection")
			},
			columns: {
				Login: {
					dataValueType: Terrasoft.DataValueType.TEXT,
					isRequired: true
				},
				Password: {
					dataValueType: Terrasoft.DataValueType.TEXT,
					isRequired: true
				},
				NewPassword: {
					dataValueType: Terrasoft.DataValueType.TEXT,
					isRequired: window.changePasswordMode === true
				},
				ConfirmPassword: {
					dataValueType: Terrasoft.DataValueType.TEXT,
					isRequired: window.changePasswordMode === true
				},
				Workspace: {
					dataValueType: Terrasoft.DataValueType.LOOKUP,
					isRequired: (window.workspaceCount > 1) && (!window.hideWorkspace)
				},
				Loading: {
					dataValueType: Terrasoft.DataValueType.BOOLEAN
				}
			},
			methods: {

				//region Fields: Private

				_loginResponseCode: {
					/** Authentication successful. */
					SUCCESS: 0,
					/** Authentication failed. */
					ERROR: 1,
					/** Authentication successful, password change recommended. */
					CHANGEPASSWORDINFO: 2,
					/** Authentication successful, user does not have a license to login but have permissions to manage licenses. */
					NEED_GRANT_LICENSE: 3,
					/** Authentication successful, user does not have a license to login and does not have permissions to manage licenses. */
					NO_LICENSE: 4,
					PASSWORDEXPIRED: 5
				},

				_loginErrorCode: {
					GENERAL: "0",
					NOT_ALLOWED_IP_ADDRESS: "4",
					PASSWORD_EXPIRED: "5",
					CHANGE_PASSWORD: "8",
					INVALID_USER_TIMEZONE: "10"
				},

				//endregion

				//region Methods: Private

				_containsIgnoreCase: function(str, searchStr) {
					return str.toUpperCase().indexOf(searchStr.toUpperCase()) !== -1;
				},

				_redirectToReturnUrl: function(responseData, response, windowLocation) {
					const redirectUrl = this._getRedirectUrl(responseData, response, windowLocation);
					windowLocation.replace(redirectUrl);
				},

				_getRedirectUrl: function(responseData, response, windowLocation) {
					if (responseData && responseData.RedirectUrl) {
						return responseData.RedirectUrl;
					}
					const responseHeaderLocation = this._getLocationFromHeaders(response);
					const windowUrlHasRedirectUrl = this._containsIgnoreCase(windowLocation.href, _returnUrlCode);
					if (windowUrlHasRedirectUrl) {
						let queryString = this._getWindowQueryString(windowLocation);
						if (windowLocation.hash) {
							queryString = this._prepareQueryString(queryString, responseHeaderLocation);
						}
						const hasQuerystring = this._containsIgnoreCase(windowLocation.pathname, queryString);
						const hasSimpleLogin = this._containsIgnoreCase(queryString, Terrasoft.simpleLoginTag);
						return hasQuerystring || hasSimpleLogin
							? responseHeaderLocation + _viewModuleAddress
							: queryString;
					} else {
						return responseHeaderLocation.indexOf(_workspaceExplorerUrl) === -1
							? responseHeaderLocation + _viewModuleAddress + windowLocation.hash
							: responseHeaderLocation;
					}
				},

				_redirectWithPasswordChangePrompt: function(responseData) {
					Terrasoft.utils.showMessage({
						caption: responseData.Message,
						buttons: ["yes", "no"],
						defaultButton: 0,
						style: Terrasoft.MessageBoxStyles.BLUE,
						handler: function(buttonCode) {
							if (buttonCode === "no") {
								this._redirectToRequestedLocation(responseData);
							} else {
								this._redirectToPasswordChangeUrl(responseData);
							}
						}.bind(this)
					});
				},

				_redirectToRequestedLocation: function(responseData) {
					const hash = window.location.hash;
					window.location.replace(responseData.RedirectUrl + _viewModuleAddress + hash);
				},

				_redirectToPasswordChangeUrl: function(responseData) {
					window.location.replace(responseData.PasswordChangeUrl);
				},

				_getWindowQueryString: function(windowLocation) {
					const encodedQueryString = windowLocation.search.replace(_returnUrlCode, "");
					const decodedQueryString = decodeURIComponent(encodedQueryString);
					const queryString = this.deleteDuplicateQueryStrings(decodedQueryString) + windowLocation.hash;
					return queryString;
				},

				_prepareQueryString: function(queryString, responseHeaderLocation) {
					const hasWorkspaceNumberRegex = new RegExp(/^\/\d+/, "g");
					const queryStartsWithAppName = queryString.startsWith(responseHeaderLocation);
					const appNameStartsWithQuery = responseHeaderLocation.startsWith(queryString);

					if (queryStartsWithAppName || appNameStartsWithQuery) {
						return queryString;
					} else if (hasWorkspaceNumberRegex.test(queryString)) {
						return responseHeaderLocation + queryString.substring(hasWorkspaceNumberRegex.lastIndex);
					} else if (queryString.startsWith("/")) {
						return responseHeaderLocation + queryString;
					}

					return responseHeaderLocation + "/" + queryString;
				},

				_getLocationFromHeaders: function(response) {
					const responseHeaders = response.getAllResponseHeaders();
					return responseHeaders.location || "";
				},

				_processLoginError: function(response) {
					this.hideLoginMask();
					if (response.status === 401) {
						this.showInfoMessage(Terrasoft.Resources.LoginPage.WrongLoginPassword);
					} else if (response.status === 403) {
						this._clearPasswordsInModel();
						this.showInfoMessage(Terrasoft.Resources.LoginPage.ChangePasswordAccessDenied);
					} else {
						throw new Terrasoft.UnauthorizedException({
							message: response.responseText
						});
					}
				},

				_clearPasswordsInModel: function() {
					const model = _module.model;
					model.set("Password", "");
					model.set("NewPassword", "");
					model.set("ConfirmPassword", "");
				},

				_initParametersFromQueryString: function() {
					const location = this._getWindowQueryString(window.location);
					const properies = Ext.Object.fromQueryString(location);
					const errorCode = properies && properies.ErrorCode;
					this._setErrorProperties(errorCode);
				},

				_setErrorProperties: function(errorCode) {
					this._setAuthenticationException(errorCode);
					const changePasswordMode = this._getIsChangePasswordError(errorCode);
					window.changePasswordMode = changePasswordMode || window.changePasswordMode;
				},

				_getIsChangePasswordError: function(errorCode) {
					const loginErrorCode = this._loginErrorCode;
					return errorCode === loginErrorCode.PASSWORD_EXPIRED ||
						errorCode === loginErrorCode.CHANGE_PASSWORD;
				},

				_setAuthenticationException: function(errorCode) {
					const authenticationException = Terrasoft.authenticationException;
					if (authenticationException) {
						return;
					}
					const authErrorExceptions = Terrasoft.AuthErrorExceptions || {};
					const message = authErrorExceptions[errorCode];
					if (message) {
						Terrasoft.authenticationException = {
							"message": message
						};
					}
				},

				_tryShowAuthenticationErrorMsg: function() {
					const authenticationException = Terrasoft.authenticationException;
					if (authenticationException) {
						Terrasoft.showMessage({
							caption: authenticationException.message,
							style: Terrasoft.MessageBoxStyles.BLUE,
							buttons: ["ok"],
							defaultButton: 0
						});
					}
				},

				_showLicMessage: function(caption, showRedirectButton, handler) {
					pleaseWaitCaption = "У вас нет лицензии для доступа к приложению. Система определяет вам доступную лицензию. Пожалуйста, ожидайте. Время ожидания: ";
					pleaseTryAgainCaption = "Система определила доступные вам лицензии. Пожалуйста, попробуйте выполнить вход еще раз. При возникновении ошибки, пожалуйста, обратитесь к системному администратору";
					caption = "Невозможно выполнить вход в систему: нет свободных лицензии для входа в приложение";
					closebuttonCaption = showRedirectButton ? "Закрыть" : "Попробовать снова";
					const waitSec = 60;
					const loginResources = Terrasoft.Resources.LoginPage;
					const emptyButtons = [{
						className: "Terrasoft.Button",
						returnCode: "",
						caption: ""
					}];
					const tryAgainButtons = [{
						className: "Terrasoft.Button",
						returnCode: "",
						caption: closebuttonCaption
					}];
					const buttons = [{
						className: "Terrasoft.Button",
						returnCode: "close",
						caption: loginResources.CloseLicMessage
					}];
					if(showRedirectButton || _licenseFailure){
						Terrasoft.showMessage({
							caption: caption,
							scope: this,
							handler: handler,
							style: Terrasoft.MessageBoxStyles.BLUE,
							buttons: buttons,
							defaultButton: 0
						});
					}
					else{
						_licenseFailure = true;
						Terrasoft.showMessage({
							caption: pleaseWaitCaption,
							scope: this,
							handler: handler,
							style: Terrasoft.MessageBoxStyles.BLUE,
							buttons: emptyButtons,
							defaultButton: 0
						});
						var timerExpiredDateTime = new Date(Date.now() + waitSec*1000);
						var dots = 0;
						var dotsText = "";
						var countdownTimer =
							setInterval(function() {
								var secondsLeft = Math.round((timerExpiredDateTime-Date.now())/1000);
								if (dots >= 4){
									dots = 0;
								}
								switch (dots) {
									case 0:
										dotsText = "";
										break;
									case 1:
										dotsText = ".";
										break;
									case 2:
										dotsText = "..";
										break;
									case 3:
										dotsText = "...";
										break;
									default:
										dotsText = "";
										break;
								}
								
								if (document.getElementById("t-comp0-wrap").style.display !== "none"){
									document.getElementById("t-comp0-caption").innerHTML = pleaseWaitCaption + secondsLeft + dotsText;
									dots++;
								}
								else{
									clearInterval(countdownTimer);
								}
								if (secondsLeft <= 0) {
									clearInterval(countdownTimer);
    								Terrasoft.showMessage({
										caption: pleaseTryAgainCaption,
										scope: this,
										handler: handler,
										style: Terrasoft.MessageBoxStyles.BLUE,
										buttons: tryAgainButtons,
										defaultButton: 0
									})
								}
							}, 250);
					}
				},

				_createLicenseManagerRedirectHandler: function(redirectUrl) {
					return function(result) {
						if (result === "redirect") {
							window.open((redirectUrl || "") + _licenseManagerUrl, "_self");
						}
					};
				},

				//endregion

				getWorkspaceList: function(filter, list) {
					list.clear();
					list.loadAll(window.workspaceList);
				},

				doLogin: function(urlValue, jsonDataValue) {
					this.showLoginMask();
					const options = {
						url: urlValue,
						headers: {
							"Content-Type": "application/json",
							"Accept": "application/json"
						},
						scope: this,
						callback: this.loginRequestCallback,
						jsonData: jsonDataValue,
						securitySensitiveFields: ["UserPassword"]
					};
					if (window.loginTimeout) {
						options.timeout = window.loginTimeout;
					}
					Terrasoft.AjaxProvider.request(options);
				},

				showLoginMask: function() {
					this.set("Loading", true);
				},

				hideLoginMask: function() {
					this.set("Loading", false);
				},

				getWorkspaceName: function() {
					let workspace = _module.model.get("Workspace");
					if (workspace) {
						workspace = workspace.value;
					}
					return workspace;
				},

				showInfoMessage: function(captionValue) {
					Terrasoft.utils.showMessage({
						caption: captionValue,
						buttons: ["ok"],
						defaultButton: 0,
						style: Terrasoft.MessageBoxStyles.BLUE
					});
				},

				onLoginButtonClick: function(skipValidation) {
					this.actualizeLoginData();
					if (!skipValidation && !this.validate()) {
						return;
					}
					this.doLogin(Terrasoft.loginUrl, {
						UserName: _module.model.get("Login"),
						UserPassword: _module.model.get("Password"),
						WorkspaceName: this.getWorkspaceName(),
						TimeZoneOffset: new Date().getTimezoneOffset()
					});
				},

				onChangePasswordLoginButtonClick: function() {
					if (!this.validate()) {
						return;
					}
					const model = _module.model;
					const password = model.get("Password");
					const newPassword = model.get("NewPassword");
					const confirmPassword = model.get("ConfirmPassword");
					if (password === newPassword) {
						this.showInfoMessage(Terrasoft.Resources.LoginPage.WrongNewPassword);
						return;
					}
					if (newPassword !== confirmPassword) {
						this.showInfoMessage(Terrasoft.Resources.LoginPage.WrongConfirmPassword);
						return;
					}
					this.doLogin(Terrasoft.changePasswordUrl, {
						UserName: model.get("Login"),
						UserPassword: password,
						WorkspaceName: this.getWorkspaceName(),
						TimeZoneOffset: new Date().getTimezoneOffset(),
						NewUserPassword: newPassword,
						ConfirmUserPassword: confirmPassword
					});
				},

				onKeyUp: function(e) {
					if (e && e.keyCode === e.ENTER) {
						if (window.changePasswordMode === true) {
							this.onChangePasswordLoginButtonClick();
						} else {
							this.onLoginButtonClick();
						}
					}
				},

				deleteDuplicateQueryStrings: function(url) {
					let resultUrl = "";
					url.split("&").forEach(function(element, index) {
						if (resultUrl.indexOf(element.split("=")[0]) !== -1) {
							return false;
						}
						if (index === 0) {
							resultUrl = resultUrl + element;
							return;
						}
						resultUrl = resultUrl + "&" + element;
					});
					return resultUrl;
				},

				loginRequestCallback: function(request, success, response) {
					if (success && response.status === 200) {
						const responseData = Ext.decode(response.responseText);
						switch (responseData.Code) {
							case this._loginResponseCode.SUCCESS:
							case this._loginResponseCode.PASSWORDEXPIRED:
								return this._redirectToReturnUrl(responseData, response, window.location);
							case this._loginResponseCode.CHANGEPASSWORDINFO:
								return this._redirectWithPasswordChangePrompt(responseData);
							case this._loginResponseCode.NEED_GRANT_LICENSE:
								this._showLicMessage(responseData.Message, true,
									this._createLicenseManagerRedirectHandler(responseData.RedirectUrl));
								break;
							case this._loginResponseCode.NO_LICENSE:
								this._showLicMessage(responseData.Message);
								break;
							case this._loginResponseCode.ERROR:
							default:
								this.showInfoMessage(responseData.Message || Terrasoft.Resources.LoginPage.AuthFailed);
						}
					}
					this._processLoginError(response);
				},

				init: function() {
					this._initParametersFromQueryString();
					const licManagerException = Terrasoft.licManagerException;
					if (licManagerException) {
						this._showLicMessage(licManagerException.message, !Ext.isEmpty(licManagerException.licManagerUrl),
							this.redirectToLicManager);
					}
					this._tryShowAuthenticationErrorMsg();
				},

				redirectToLicManager: function(result) {
					if (result === "redirect") {
						window.location.replace(Terrasoft.licManagerException.licManagerUrl);
					}
				},

				onNtlmLoginClick: function() {
					this.showLoginMask();
					if (Terrasoft.appFramework === "NETCOREAPP") {
						this.doLogin("/ServiceModel/AuthService.svc/DomainLogin", {});
					} else {
						let url = Terrasoft.ntlmLoginUrl;
						if (window.location.hash) {
							url = url + window.location.hash;
						}
						window.location = url;
					}
				},

				actualizeLoginData: function() {
					const reloadModelValue = function(componentId) {
						const el = Ext.getCmp(componentId).getEl();
						el.focus();
						el.blur();
					};
					reloadModelValue("loginEdit");
					reloadModelValue("passwordEdit");
				},

				onDocumentKeyDown: function(e) {
					if (e && e.keyCode === e.ENTER) {
						if (e.ctrlKey) {
							this.actualizeLoginData();
							const model = _module.model;
							const skipValidation = model && !model.get("Login") && !model.get("Password");
							this.onLoginButtonClick(skipValidation);
						} else if (e.altKey && window.isNtlmLoginVisible) {
							this.onNtlmLoginClick();
						}
					}
				}
			}
		});
	};

	return {
		renderTo: Ext.getBody(),
		init: init,
		render: function(renderTo) {
			if (Terrasoft.SsoUtils.getNeedShowSsoLogin()) {
				Terrasoft.SsoUtils.initiateSsoLogin();
				return;
			}
			prepareModel();
			_module.model.init();
			renderView(renderTo);
			_module.view.bind(_module.model);
			const userName = Ext.String.htmlDecode(window.userName);
			if (userName) {
				_module.model.set("Login", userName);
				if (window.isDebug === true) {
					_module.model.set("Password", userName);
				}
			}
			if (window.workspaceCount <= 1 || window.hideWorkspace) {
				_module.view.hideWorkspaceEdit();
			} else {
				const workspace = window.workspace;
				if (workspace) {
					const modelValue = {
						value: workspace,
						displayValue: workspace
					};
					_module.model.set("Workspace", modelValue);
				}
			}
			if (window.changePasswordMode === true) {
				_module.view.showChangePasswordMode();
			} else {
				_module.view.showLoginMode();
			}
			const doc = Ext.getDoc();
			doc.on("keydown", _module.model.onDocumentKeyDown, _module.model);
		}
	};
});
